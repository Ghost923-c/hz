import { motion } from 'motion/react';
import { ArrowRight, ShoppingBag, Menu, X, Instagram, Facebook } from 'lucide-react';
import { useState } from 'react';

const ranges = [
  {
    id: 'gazi',
    name: 'GAZI',
    pronunciation: 'gah-zee',
    color: 'bg-[#782F2F]',
    textColor: 'text-[#782F2F]',
    description: 'Literally "blood". A deep, rich maroon that feels powerful, grounded, and traditional.',
    image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?q=80&w=1887&auto=format&fit=crop', // Placeholder for maroon
  },
  {
    id: 'luthuli',
    name: 'LUTHULI',
    pronunciation: 'loo-too-lee',
    color: 'bg-[#8B8B6B]',
    textColor: 'text-[#8B8B6B]',
    description: 'Meaning "dust". A poetic, earthy khaki that evokes the timeless African landscape.',
    image: 'https://images.unsplash.com/photo-1516762689617-e1cffcef479d?q=80&w=1911&auto=format&fit=crop', // Placeholder for khaki
  },
  {
    id: 'luhlaza',
    name: 'LUHLAZA',
    pronunciation: 'loo-shla-za',
    color: 'bg-[#2E5C45]',
    textColor: 'text-[#2E5C45]',
    description: 'The essence of nature. A fresh, vibrant green that connects you to the outdoors.',
    image: 'https://images.unsplash.com/photo-1550614000-4b9519e02a48?q=80&w=1887&auto=format&fit=crop', // Placeholder for green
  },
];

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#f9f8f6] text-stone-900 overflow-x-hidden selection:bg-stone-200">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-[#f9f8f6]/80 backdrop-blur-md border-b border-stone-200/50">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <a href="#" className="font-serif text-3xl font-bold tracking-tighter">Hz</a>
          
          <div className="hidden md:flex items-center space-x-8 font-medium text-sm tracking-widest uppercase">
            <a href="#collections" className="hover:text-stone-600 transition-colors">Collections</a>
            <a href="#about" className="hover:text-stone-600 transition-colors">Philosophy</a>
            <a href="#contact" className="hover:text-stone-600 transition-colors">Contact</a>
            <button className="bg-stone-900 text-white px-6 py-2 rounded-full hover:bg-stone-800 transition-colors">
              Shop Now
            </button>
          </div>

          <button 
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:hidden absolute top-20 left-0 w-full bg-[#f9f8f6] border-b border-stone-200 p-6 flex flex-col space-y-4"
          >
            <a href="#collections" className="text-lg font-serif" onClick={() => setIsMenuOpen(false)}>Collections</a>
            <a href="#about" className="text-lg font-serif" onClick={() => setIsMenuOpen(false)}>Philosophy</a>
            <a href="#contact" className="text-lg font-serif" onClick={() => setIsMenuOpen(false)}>Contact</a>
          </motion.div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden pt-20">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1445205170230-053b83016050?q=80&w=2071&auto=format&fit=crop" 
            alt="Linen Texture" 
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-90"
          />
          <div className="absolute inset-0 bg-black/10" />
        </div>

        <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
          <motion.span 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="block text-white text-sm md:text-base tracking-[0.3em] uppercase mb-4"
          >
            Premium South African Linen
          </motion.span>
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="font-serif text-6xl md:text-8xl lg:text-9xl text-white mb-8 leading-none"
          >
            Hz
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-white/90 text-lg md:text-2xl font-light max-w-2xl mx-auto mb-12"
          >
            Clothing for high vibrational human beings.
            <br />
            Localized supply. Conscious craft.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <a 
              href="#collections" 
              className="inline-flex items-center space-x-2 bg-white text-stone-900 px-8 py-4 rounded-full hover:bg-stone-100 transition-all transform hover:scale-105"
            >
              <span className="uppercase tracking-widest text-sm font-medium">Explore Ranges</span>
              <ArrowRight size={16} />
            </a>
          </motion.div>
        </div>
      </section>

      {/* Collections Section */}
      <section id="collections" className="py-24 px-6 md:px-12 max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <h2 className="font-serif text-5xl md:text-6xl mb-6 text-stone-800">The Collections</h2>
          <p className="text-stone-600 max-w-xl mx-auto text-lg">
            Three distinct ranges inspired by the South African landscape.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {ranges.map((range, index) => (
            <motion.div 
              key={range.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="group cursor-pointer"
            >
              <div className="relative overflow-hidden rounded-2xl aspect-[3/4] mb-6">
                <div className={`absolute inset-0 ${range.color} opacity-20 group-hover:opacity-10 transition-opacity duration-500`} />
                <img 
                  src={range.image} 
                  alt={range.name} 
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute bottom-0 left-0 w-full p-6 bg-gradient-to-t from-black/50 to-transparent">
                  <h3 className="text-white font-serif text-4xl tracking-wide">{range.name}</h3>
                </div>
              </div>
              <div className="text-center">
                <p className={`text-sm font-bold tracking-widest uppercase mb-1 ${range.textColor}`}>
                  {range.name} Collection
                </p>
                <p className="text-xs text-stone-400 italic mb-3">
                  Pronounced: {range.pronunciation}
                </p>
                <p className="text-stone-600 font-light leading-relaxed">
                  {range.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Philosophy / About Section */}
      <section id="about" className="py-24 bg-stone-200">
        <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div className="order-2 md:order-1">
            <img 
              src="https://images.unsplash.com/photo-1558769132-cb1f1d53bc6b?q=80&w=1974&auto=format&fit=crop" 
              alt="Linen Fabric Detail" 
              referrerPolicy="no-referrer"
              className="rounded-2xl shadow-xl w-full object-cover aspect-square"
            />
          </div>
          <div className="order-1 md:order-2">
            <span className="block text-stone-500 text-sm tracking-[0.2em] uppercase mb-4">Our Philosophy</span>
            <h2 className="font-serif text-5xl md:text-6xl mb-8 text-stone-900 leading-tight">
              Localized Supply. <br />
              <span className="italic text-stone-600">High Vibration.</span>
            </h2>
            <p className="text-lg text-stone-700 font-light mb-6 leading-relaxed">
              Hz is more than a clothing brand; it's a frequency. We believe that what you wear affects how you feel and how you interact with the world.
            </p>
            <p className="text-lg text-stone-700 font-light mb-8 leading-relaxed">
              Our premium linen is sourced and stitched locally in South Africa, supporting our community and reducing our carbon footprint. Each piece is crafted with intention for the conscious individual.
            </p>
            <div className="flex items-center space-x-12">
              <div>
                <span className="block font-serif text-3xl mb-1">100%</span>
                <span className="text-xs uppercase tracking-widest text-stone-500">Premium Linen</span>
              </div>
              <div>
                <span className="block font-serif text-3xl mb-1">Local</span>
                <span className="text-xs uppercase tracking-widest text-stone-500">Supply Chain</span>
              </div>
              <div>
                <span className="block font-serif text-3xl mb-1">3</span>
                <span className="text-xs uppercase tracking-widest text-stone-500">Unique Ranges</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Marquee / Vibe Section */}
      <div className="py-12 bg-[#782F2F] overflow-hidden">
        <div className="flex whitespace-nowrap">
          {[...Array(10)].map((_, i) => (
            <span key={i} className="text-white/80 font-serif text-4xl mx-8 italic">
              High Vibrational Living
            </span>
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer id="contact" className="bg-stone-900 text-stone-400 py-20 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="col-span-1 md:col-span-2">
            <h2 className="font-serif text-4xl text-white mb-6">Hz</h2>
            <p className="max-w-md font-light mb-8">
              Premium linen clothing for men and women. 
              Elevate your frequency with conscious fashion from South Africa.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-white transition-colors"><Instagram /></a>
              <a href="#" className="hover:text-white transition-colors"><Facebook /></a>
            </div>
          </div>
          
          <div>
            <h3 className="text-white uppercase tracking-widest text-sm font-bold mb-6">Shop</h3>
            <ul className="space-y-4 font-light">
              <li><a href="#" className="hover:text-white transition-colors">All Collections</a></li>
              <li><a href="#" className="hover:text-white transition-colors">GAZI (Maroon)</a></li>
              <li><a href="#" className="hover:text-white transition-colors">LUTHULI (Khaki)</a></li>
              <li><a href="#" className="hover:text-white transition-colors">LUHLAZA (Green)</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white uppercase tracking-widest text-sm font-bold mb-6">Contact</h3>
            <ul className="space-y-4 font-light">
              <li>hello@hz-linen.co.za</li>
              <li>Cape Town, South Africa</li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-white/10 text-xs tracking-widest uppercase flex justify-between">
          <span>&copy; {new Date().getFullYear()} Hz Linen. All rights reserved.</span>
          <span>Designed with Intention</span>
        </div>
      </footer>
    </div>
  );
}
